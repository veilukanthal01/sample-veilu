window.addEventListener('load', getData);

let index = 0;
let filteredData = [];
let filteredDataIndex = 0;

let previous = document.getElementById('previous');
let next = document.getElementById('next');

previous.addEventListener('click', function () {
    var inputStr = document.getElementById("job").value;
    if ((inputStr == '' || inputStr == 'Enter job name')) {
        if (index > 0) {
            previous.style.visibility = 'visible';
            next.style.visibility = 'visible';
            displayCandidate(obj.resume[--index]);
        }
        else if (index == 0) {
            next.style.visibility = 'visible';
            previous.style.visibility = 'hidden';
        }
    }
    else {
        if (filteredDataIndex > 0) {
            previous.style.visibility = 'visible';
            next.style.visibility = 'visible';
            displayFilteredCandidate(filteredData[--filteredDataIndex]);
        }
        else if (filteredDataIndex == 0) {
            next.style.visibility = 'visible';
            previous.style.visibility = 'hidden';
        }

    }

});

next.addEventListener('click', function () {
    var inputStr = document.getElementById("job").value;
    if ((inputStr == '' || inputStr == 'Enter job name')) {
        if (index < (obj.resume.length - 1)) {
            next.style.visibility = 'visible';
            previous.style.visibility = 'visible';
            displayCandidate(obj.resume[++index]);
        }
        else if (index == (obj.resume.length - 1)) {
            previous.style.visibility = 'visible';
            next.style.visibility = 'hidden';
        }
    }
    else {
        if (filteredDataIndex < (filteredData.length - 1)) {
            next.style.visibility = 'visible';
            previous.style.visibility = 'visible';
            displayFilteredCandidate(filteredData[++filteredDataIndex]);
        }
        else if (filteredDataIndex == (filteredData.length - 1)) {
            previous.style.visibility = 'visible';
            next.style.visibility = 'hidden';
        }

    }

});


//FETCH CALLS
function getData() {

    fetch('Data.json')
        .then(checkStatus)
        .then(response => response.json())
        .then(data => obj = data)
        .then(() => displayCandidate(obj))
        .then(getResponse)
}


function checkStatus(response) {
    if (response.ok) {
        return Promise.resolve(response);
    } else {
        return Promise.reject(new Error(response.statusText));
    }
}

function displayCandidate() {
    if (index == 0) {
        next.style.visibility = 'visible';
        previous.style.visibility = 'hidden';
    }
    if (index == (obj.resume.length - 1)) {
        previous.style.visibility = 'visible';
        next.style.visibility = 'hidden';
    }
    document.querySelector('#candidate-name').innerHTML = obj.resume[index].basics.name;
    document.querySelector('#applied-for').innerHTML = 'Applied for : ' + obj.resume[index].basics.AppliedFor;
    document.querySelector('#work-experience-company-name').innerHTML = obj.resume[index].work['Company Name'];

}

function displayFilteredCandidate() {
    if (filteredDataIndex == 0) {
        next.style.visibility = 'visible';
        previous.style.visibility = 'hidden';
    }
    if (filteredDataIndex == (filteredData.length - 1)) {
        previous.style.visibility = 'visible';
        next.style.visibility = 'hidden';
    }
    document.querySelector('#candidate-name').innerHTML = filteredData[filteredDataIndex].basics.name;
    document.querySelector('#applied-for').innerHTML = 'Applied for : ' + filteredData[filteredDataIndex].basics.AppliedFor;
    document.querySelector('#work-experience-company-name').innerHTML = filteredData[filteredDataIndex].work['Company Name'];

}


function getResponse() {
    return obj;
}

function filterJobData(job) {

    if (job != '') {
        filteredData = obj.resume.filter(function (item) {
            return item.basics["AppliedFor"].toLowerCase().indexOf(job.toLowerCase()) != -1
        });
    }
    return filteredData;
}

function getFilterCandidatesJson() {

    var inputStr = document.getElementById("job").value;

    if ((inputStr == '' || inputStr == 'Enter job name')) {
        alert("Please enter job name.");
        document.getElementById("job").focus();
        return false;
    }

    var filterObjs = filterJobData(inputStr);

}